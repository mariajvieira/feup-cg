# CG 2024/2025

## Group T12G10

## TP 2 Notes

### Main observations/remarks 
- We had some trouble undestanding how the translation matrix worked for the diamond.
- There were no big difficulties in general.

#### Exercise 2 Screenshots

- Tangram: 

![MyTangram](screenshots/cg-t12-g10-tp2-1.png)

#### Exercise 3 Screenshots

- Tangram with the base:

![MyUnitCube](screenshots/cg-t12-g10-tp2-2.png)

- Tangram with the base - parallel to the XZ plane:

![MyUnitCube](screenshots/cg-t12-g10-tp2-3.png)


#### Exercise 4 Screenshots

- Cube composed of planes:

![MyUnitCubeQuad](screenshots/cg-t12-g10-tp2-4.png)

- Cube with the tangram :

![MyUnitCubeQuad transformed](screenshots/cg-t12-g10-tp2-5.png)