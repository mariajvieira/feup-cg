# CG 2024/2025

## Group T12G10

## TP 4 Notes

### Main observations/remarks 
- At first, it took us a while to figure out how the textures coordinates worked.
- Overall, we didn´t have many difficuties in this week's exercises.

#### Exercise 1 Screenshots

- Tangram with the texture from tangram.png: 

![Tangram](screenshots/cg-t12-g10-tp4-1.png)

#### Exercise 2 Screenshots

- Cube with textures: 

![Cube](screenshots/cg-t12-g10-tp4-2.png)

