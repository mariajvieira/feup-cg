# CG 2024/2025

## Group T12G10

## TP 1 Notes

### Main observations/remarks 
- In the beggining of the exercises, we had some trouble understanding how to make the objects double-sided.
- There were no big difficulties in general.

#### Exercise 1 Screenshots

- MyDiamond: 

![MyDiamond](screenshots/cg-t12g10-tp1-0.png)

- MyTriangle: 

![MyTriangle](screenshots/cg-t12g10-tp1-1.png)

- MyParallelogram: 

![MyParallelogram](screenshots/cg-t12g10-tp1-2.png)

#### Exercise 2 Screenshots

- MyTriangleSmall: 

![MyTriangleSmall](screenshots/cg-t12g10-tp1-5.png)

- MyTriangleBig: 

![MyTriangleBig](screenshots/cg-t12g10-tp1-6.png)